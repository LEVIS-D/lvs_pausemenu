LVS = {}

LVS.OpenKey = 'ESCAPE'                                 -- Pause Menu Key (https://docs.fivem.net/docs/game-references/controls/)
LVS.ServerName = 'LEVIS ROLEPLAY'                      -- Server Name
LVS.GiftCount = 5000                                   -- Christmas Gift Money Count

LVS.Lang = {
	['pausemenu'] = 'Open Pause Menu',
	['male'] = "Male",
	['female'] = 'Female',
	['quit'] = 'Exiting the '..LVS.ServerName,
	['already'] = 'You already got your Christmas Gift!',
	['gift'] = 'You Won '..LVS.GiftCount..'$ Christmas Gift'
}

-- This script made by levis.
-- For technical support; discord.gg/MVp2DHKr65, onur.yd.