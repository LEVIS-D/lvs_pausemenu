fx_version 'adamant'

game 'gta5'

client_scripts {
	'config.lua',
	'client.lua'
}

server_scripts {
	'config.lua',
    'server.lua'
}

ui_page "html/index.html"

files {
	"html/index.html",
	"html/js/jquery-3.6.0.min.js",
	"html/img/*.png",
	"html/img/*.jpg",
	"html/js/listener.js",
	"html/style.css",
}

-- This script made by levis.
-- For technical support; discord.gg/MVp2DHKr65, onur.yd.