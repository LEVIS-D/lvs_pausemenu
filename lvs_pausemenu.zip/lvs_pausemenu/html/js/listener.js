$(document).ready(function(){

    function display(bool) {
        if (bool) {
            $("#overlay").show();
        } else {
            $("#overlay").hide();
        }
    }

    display(false)

    window.addEventListener('message', function(event) {
        var item = event.data;
        if (item.type === "open") {
            if (item.status == true) {
                display(true)
                $("#name").html(addCommas((String(event.data.name))))
                $("#gender").html(addCommas((String(event.data.gender))))
                $("#cash").html(addCommas((String(event.data.cash))))
                $("#cash").prepend("$")
                $("#bank").html(addCommas((String(event.data.bank))))
                $("#bank").prepend("$")
                $("#jobLabel").html(addCommas((String(event.data.jobLabel))))
                $("#jobGrade").html(addCommas((String(event.data.jobGrade))))
                $("#street").html(addCommas((String(event.data.street))))
                $("#time").html(addCommas((String(event.data.time))))
                $("#server").html(addCommas((String(event.data.server))))
                $("#players").html(addCommas((String(event.data.players))))
                $("#maxPlayers").html(addCommas((String(event.data.maxPlayers))))
            } else {
                display(false)
            }
        }
    });

    function addCommas(inputText) {
        var commaPattern = /(\d+)(\d{3})(\.\d*)*$/;
        var callback = function (match, p1, p2, p3) {
            return p1.replace(commaPattern, callback) + '.' + p2 + (p3 || '');
        };
        return inputText.replace(commaPattern, callback);
    }

    $("#settings").click(function() {
        $('#overlay').fadeOut()
        $.post('https://lvs_pausemenu/action', JSON.stringify({action:'settings'}));
        return
    })

    $("#map").click(function() {
        $('#overlay').fadeOut()
        $.post('https://lvs_pausemenu/action', JSON.stringify({action:'map'}));
        return
    })

    $("#quit").click(function() {
        $.post('https://lvs_pausemenu/action', JSON.stringify({action:'quit'}));
        return
    })

    $('#social').click(function(){
        window.invokeNative('openUrl', 'https://www.youtube.com/@levisdev1504/')         // You should edit here by your url  
    })

    $('#resume').click(function(){
        $('#overlay').fadeOut()
        $.post('https://lvs_pausemenu/action', JSON.stringify({action:'close'}));
        return
    })

    $('#gift').click(function(){
        $('#overlay').fadeOut()
        $.post('https://lvs_pausemenu/action', JSON.stringify({action:'gift'}));
        return
    })

    // document.onkeyup = function(data) {
    //     if (data.which == 27) {
    //         $('#overlay').fadeOut()
    //         $.post('https://lvs_pausemenu/action', JSON.stringify({action:'close'}));
    //         return
    //     }
    // };

});